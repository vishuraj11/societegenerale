/**
 * 
 */
package com.test.societegenerale.EmployeePortal.model;

/**
 * @author Rajendra.kushawaha
 *
 */
public class Employee {

}

/**
 * 
 */
package com.test.societegenerale.EmployeePortal.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.societegenerale.EmployeePortal.model.Employee;
import com.test.societegenerale.EmployeePortal.model.EmployeeRequest;
import com.test.societegenerale.EmployeePortal.model.EmployeeResponce;
import com.test.societegenerale.EmployeePortal.repo.EmployeeRepo;
import com.test.societegenerale.EmployeePortal.service.EmployeeService;

/**
 * @author Rajendra.kushawaha
 *
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;
	
	@Override
	public EmployeeResponce employeeRegistration(EmployeeRequest emp) {
		EmployeeResponce empResp=new EmployeeResponce();
		if(!emp.equals(null)) {
		empResp=employeeRepo.saveEmployee(emp);
		}
		return empResp;
	}

	@Override
	public List<Employee> getgetEmployeeList() {
		
		return employeeRepo.findAllEmployee();
	}

}

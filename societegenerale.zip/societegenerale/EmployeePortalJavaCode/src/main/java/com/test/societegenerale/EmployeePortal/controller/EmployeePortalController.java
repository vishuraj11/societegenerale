/**
 * 
 */
package com.test.societegenerale.EmployeePortal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.societegenerale.EmployeePortal.model.Employee;
import com.test.societegenerale.EmployeePortal.model.EmployeeRequest;
import com.test.societegenerale.EmployeePortal.model.EmployeeResponce;
import com.test.societegenerale.EmployeePortal.service.EmployeeService;


/**
 * @author Rajendra.kushawaha
 *
 */
@RestController
@RequestMapping("api")
public class EmployeePortalController {
	
	@Autowired
	private EmployeeService employeeService;

	@PostMapping("/regEmployee")
	public EmployeeResponce employeeRegistration(EmployeeRequest emp) {
		
		return employeeService.employeeRegistration(emp);
	}
	
	@GetMapping("/getEmployee")
	public List<Employee> getEmployee() {
		
		return employeeService.getgetEmployeeList();
	}
}

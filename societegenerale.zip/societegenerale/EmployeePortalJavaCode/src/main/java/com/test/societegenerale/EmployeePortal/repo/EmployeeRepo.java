/**
 * 
 */
package com.test.societegenerale.EmployeePortal.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.test.societegenerale.EmployeePortal.entity.EmployeeEntity;
import com.test.societegenerale.EmployeePortal.model.Employee;
import com.test.societegenerale.EmployeePortal.model.EmployeeRequest;
import com.test.societegenerale.EmployeePortal.model.EmployeeResponce;

/**
 * @author Rajendra.kushawaha
 *
 */
@Repository
public interface EmployeeRepo extends JpaRepository<Long, EmployeeEntity> {

	EmployeeResponce saveEmployee(EmployeeRequest emp);

	List<Employee> findAllEmployee();

}

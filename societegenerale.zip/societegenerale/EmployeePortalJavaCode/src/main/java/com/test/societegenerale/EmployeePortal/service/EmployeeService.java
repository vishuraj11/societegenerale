/**
 * 
 */
package com.test.societegenerale.EmployeePortal.service;

import java.util.List;

import com.test.societegenerale.EmployeePortal.model.Employee;
import com.test.societegenerale.EmployeePortal.model.EmployeeRequest;
import com.test.societegenerale.EmployeePortal.model.EmployeeResponce;

/**
 * @author Rajendra.kushawaha
 *
 */
public interface EmployeeService {

	EmployeeResponce employeeRegistration(EmployeeRequest emp);

	List<Employee> getgetEmployeeList();

}

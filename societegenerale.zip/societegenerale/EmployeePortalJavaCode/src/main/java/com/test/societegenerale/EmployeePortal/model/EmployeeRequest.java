/**
 * 
 */
package com.test.societegenerale.EmployeePortal.model;

/**
 * @author Rajendra.kushawaha
 *
 */
public class EmployeeRequest {
	
	private String FirstName;
	private String LastName;
	private String gender;
	private String  dob;
	private String department;
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
	
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employees } from './view-employee-list/employeeList'


@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

baseUrlString: String="http://localhost:8080/api";
  constructor(private http:HttpClient) { }

 getData(){
 return  this.http.get(this.baseUrlString+"/getEmployee");
 }

 registerEmployee(emp:Employees){
	this.http.post<any>(this.baseUrlString+"/regEmployee",emp);
 }

}

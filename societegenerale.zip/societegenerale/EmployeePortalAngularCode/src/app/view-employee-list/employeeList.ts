export  class Employees {
    firstName: String;
    LastName: String;
    gender: String;
    dateofBirth: String;
    department:String;
}
import { Component, OnInit, Input } from '@angular/core';
import {Employees} from './employeeList';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-view-employee-list',
  templateUrl: './view-employee-list.component.html',
  styleUrls: ['./view-employee-list.component.css']
})
export class ViewEmployeeListComponent implements OnInit {
  // @Input()RegistrationFormInput:any
  data:any;
  constructor( private empService:EmployeeServiceService) {
    this.data = JSON.parse(localStorage.getItem('registration'));
    console.log(this.data);
   }
  
  employees:Employees [] = [
   {
    firstName :this.data.firstName,
    LastName:this.data.lastName,
    gender:this.data.gender,
    dateofBirth:this.data.dateofBirth,
    department:this.data.department,
   }

  ];

  ngOnInit() {
     this.empService.getData().subscribe;
  }


 
}



 

  //     onClick(){
  //   
  //    }






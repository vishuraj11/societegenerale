import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router'
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-registration-page',
  templateUrl: './registration-page.component.html',
  styleUrls: ['./registration-page.component.css']
})
export class RegistrationPageComponent implements OnInit {
  registerForm: FormGroup;
  //   // loading = false;
       submitted = false;
        data : any ;
  //   // RegistrationFormValuepassing: any;
  //   // RegistrationFormValuepassing =  'checkingLogin';
  //   // RegistrationInput=this.data
  constructor(private formBuilder: FormBuilder,private router: Router,private empService:EmployeeServiceService
        ) {
          this.registerForm = this.formBuilder.group({
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            gender : ['', Validators.required],
            dateofBirth : ['', Validators.required],
            department: ['', Validators.required],
        });
       }

       get f() { return this.registerForm.controls; }
 
       

  ngOnInit() {
  }


   onSubmit() {
        this.submitted = true;
    
        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
        else{
          // localStorage.setItem('dataSource', this.registerForm.value);
          // here we are converting javascrpit object into json 
         // localStorage.setItem('registration', JSON.stringify(this.registerForm.value)); 
        //  this.data = JSON.parse(localStorage.getItem('registration'));
          // this.navCtrl
          this.empService.registerEmployee(this.registerForm.value);

       //   console.log(this.data);
         // this.router.navigate(['']);
    
         // console.log(this.registerForm.value);
    
    }


}
}
